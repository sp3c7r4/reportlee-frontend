# assistant

## Purpose

A read-only AI chat for Workspace Admins, which answers questions about the Workspace and shows where every
number came from.

No provider is wired and no model is called in this change. The panel, the context chip, the sources and the
off state are built against the documented contract, answered by a `simulate*` function. Keys and guardrails
stay in the backend, never in the app.

## ADDED Requirements

### Requirement: Admins only, and greyed when off

The Assistant MUST appear only for a Workspace Admin. When the AI features switch is off it MUST be greyed
with its reason, in the sidebar and anywhere else it is offered, rather than hidden.

#### Scenario: AI off

- **WHEN** the Workspace has AI features off and an Admin opens the app
- **THEN** the Assistant item is greyed with the reason and no panel opens

#### Scenario: A Head of Space

- **WHEN** a Head of Space uses the app
- **THEN** no Assistant entry exists for them

### Requirement: The context chip narrows, never widens

The context chip MUST show what the conversation is scoped to (Workspace, Space, period) and MUST ONLY offer
scopes the Admin can already see. Nothing the Admin could not open through the normal screens may be answered.

#### Scenario: A Space the Admin can see

- **WHEN** the chip is set to one Space
- **THEN** answers cover that Space only, and the chip says so

### Requirement: Every claim links to its sources

Every figure in an answer MUST state how many Reports it covers and MUST link to the Reports behind it. An
answer that cannot be sourced MUST say so instead of asserting a number.

#### Scenario: A count

- **WHEN** the answer says 12 Reports were late
- **THEN** it shows the coverage and a link that opens those 12

### Requirement: Conversations are private and read-only

A conversation MUST belong to the Admin who started it, MUST be visible only to them, and MUST NOT change any
Workspace data. The Assistant MUST offer no action that writes.

#### Scenario: A second Admin

- **WHEN** another Admin opens the Assistant
- **THEN** they see their own history and none of the first Admin's conversations

### Requirement: The panel and the page

The Assistant MUST be a docked panel on the right with an expand control, and a full page at
`/dashboard/assistant` with the Admin's own history. Both MUST have a sending state, an error state with
Retry, and an empty state with example questions.

#### Scenario: A failed answer

- **WHEN** an answer fails
- **THEN** the question stays in the transcript and a message offers Retry

## API contract (documented, simulated today)

| Call | Method and path | Body | Success `data` | Errors |
|---|---|---|---|---|
| Ask | `POST /api/v1/assistant/messages` | `{ conversationId?, question, context }` | `AssistantMessage` | 401, 403, 429 |
| History | `GET /api/v1/assistant/conversations` | none | `Conversation[]` | 401, 403 |

Guards: `jwt.validateToken`, then a Workspace Admin role guard, then the AI switch, then conversation
ownership. The server applies the Admin's own permissions to every tool call the model asks for.

## Frontend

- A docked panel in the shell for Admins, plus `/dashboard/assistant` with history.
- Sources render as links to the Reports list with the same filter, never as raw ids.
- Types: `AssistantMessage`, `Conversation`, `AssistantContext`, `Source` in `src/lib/assistant.ts`.
