# task-board

## Purpose

Follow-up tasks as work: a board with three columns, views that differ by role, and a completion that keeps
a note.

No backend exists. The calls below are the documented contract, answered today by `simulate*` functions in
`src/lib/reports.ts`. Who may move a card is a server rule; the board mirrors it.

## ADDED Requirements

### Requirement: Views depend on the role

A Staff member MUST see "Assigned to me". A Head of Space MUST see "Assigned to me", "Assigned by me" and
"My Space". A Workspace Admin MUST see "Assigned by me" and "Everyone", and MUST NOT be offered
"Assigned to me", because an Admin authors no Reports.

#### Scenario: An Admin opens the board

- **WHEN** a Workspace Admin opens the board
- **THEN** the views are Assigned by me and Everyone

### Requirement: Only the assignee moves a card

A card MUST be draggable only in "Assigned to me", and only by its assignee. In every other view a card MUST
show its column and MUST NOT be draggable.

#### Scenario: A reviewer tries to drag

- **WHEN** a Head tries to drag a card in "My Space" that is assigned to someone else
- **THEN** the card does not move and nothing is written

### Requirement: Completing a task keeps a note

Moving a card to Done MUST offer an optional note and an optional file, MUST record the completion time, and
MUST NOT block the move when both are skipped. Moving a card out of Done MUST clear its completion time and
its note.

#### Scenario: Completed, then reopened

- **WHEN** a completed card is moved back to In progress
- **THEN** its completed time and completion note are cleared

### Requirement: The phone moves cards without dragging

Below the medium breakpoint each card MUST offer a "Move to" menu listing the other two columns, operable
from the keyboard, and MUST NOT require a drag.

#### Scenario: Keyboard only

- **WHEN** a card's Move to menu is opened from the keyboard
- **THEN** every other column is reachable and choosing one moves the card

### Requirement: The board has the four states

The board MUST have a loading state, an error state with Retry, an empty state per column and an empty state
per view.

#### Scenario: An empty column

- **WHEN** Done has no cards
- **THEN** the column says so rather than collapsing

## API contract (documented, simulated today)

| Call | Method and path | Body | Success `data` | Errors |
|---|---|---|---|---|
| Board | `GET /api/v1/tasks?view=` | none | `FollowUpTask[]` | 401, 403 |
| Move | `PATCH /api/v1/tasks/:id` | `{ status, note?, attachment? }` | `FollowUpTask` | 401, 403, 404, 409 |

Guards: `jwt.validateToken`, then the assignee check for a move, then the view's scope on the server.

## Frontend

- `/dashboard/tasks`: view switcher, three columns, cards with due date and origin, completion dialog,
  Move to menu at 390, the four states.
- Reached from the nav's Tasks item and the Tasks tab on a phone.
- Types: `TaskStatus = "todo" | "in-progress" | "done"`, `TaskView`, `FollowUpTask` in `src/lib/tasks.ts`.
