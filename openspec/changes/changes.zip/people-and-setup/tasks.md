## 1. Rules and tests (FE)

- [ ] 1.1 `scripts/people.test.ts` red: an Admin may invite every role; a Head gets Staff only and a fixed
      Space; a Staff invitation without a Space is refused; a deactivated member keeps their Reports and leaves
      the pickers; an archived Space leaves every picker.
- [ ] 1.2 `src/lib/people.ts` and `src/lib/setup.ts` to green, including the setup completion rule.

## 2. Setup (FE)

- [ ] 2.1 Setup resumes under `/onboarding`: the Spaces step and the Invitations step, with done steps marked.
- [ ] 2.2 The Admin-only unfinished-setup banner on the dashboard names the missing steps.
- [ ] 2.3 The report form's "still being set up" state links to who can fix it.

## 3. Members and Spaces (FE)

- [ ] 3.1 `/dashboard/members`: table with invitations, filter chips for role and status, invite dialog from
      `inviteRules`, row menu (resend, deactivate, change role or Space), addresses for Admins only.
- [ ] 3.2 Rows become cards at 390 with 44px targets; loading, error with Retry, empty states.
- [ ] 3.3 `/dashboard/spaces`: cards with Head, member count and submission bar; archive and restore.
- [ ] 3.4 Space page tabs: Reports, Members, KPI template, with the template editable by a Head and prefilling
      the form.

## 4. Validation (FE)

- [ ] 4.1 `npx biome check` on the touched files, compared against the previous copy.
- [ ] 4.2 `npx tsc --noEmit`, `npm test`, `npm run build`.
- [ ] 4.3 Browser pass as Admin and Head, 1440 and 390, both themes: invite flow for both roles, a missing
      Space, deactivation, archive and restore, the template reaching the form, keyboard only.
- [ ] 4.4 Console and network clean; no mail request of any kind; em dash scan; ROADMAP row; validate.
