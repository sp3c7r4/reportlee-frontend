# review-queue

## Purpose

The reviewer's queue: Reports waiting on a decision, people who have not submitted, and the decisions.

No backend exists. The calls below are the documented contract, answered today by `simulate*` functions.
Which Reports a reviewer may decide is a server rule; the queue's scoping mirrors it and is not access
control.

## ADDED Requirements

### Requirement: Who reviews what

A Head of Space MUST review their own Space only, and a Workspace Admin the whole Workspace. A Head's own
Report MUST NOT appear in that Head's queue. A Space with no Head MUST have its Reports in the Admin queue.

#### Scenario: A Head's own Report

- **WHEN** a Head opens the queue
- **THEN** their own Report is absent there and present for a Workspace Admin

#### Scenario: A Space without a Head

- **WHEN** a Space has no Head and its Staff submitted
- **THEN** those Reports appear in the Admin queue

### Requirement: A table with filters and a not-submitted tab

The queue MUST group Reports by period, offer filter chips (All, Waiting, Approved, Rejected), and a
separate "Not submitted" tab whose rows are hatched and also say "Not submitted" in words. Rows MUST show
the person, the Space, the submitted time in the Workspace's timezone and the state pill. At 390px rows
MUST become cards.

#### Scenario: Not submitted

- **WHEN** the not-submitted tab is opened
- **THEN** each person without a Report is listed, marked in words as well as by pattern

#### Scenario: An empty filter

- **WHEN** Rejected is picked and nothing was rejected
- **THEN** an empty state names the filter and offers All

### Requirement: A decision needs what it needs

Approve MUST be available on pending Reports. Reject MUST require a reason and MUST stay disabled until one
is written. Reopen MUST be offered only on approved Reports and MUST also require a reason. Each decision
MUST record when, who and the reason.

#### Scenario: Reject without a reason

- **WHEN** Reject is pressed with an empty reason
- **THEN** nothing is posted and the field says the reason is required

#### Scenario: Reopen

- **WHEN** an approved Report is reopened with a reason
- **THEN** it returns to pending, the timeline gains Reopened, the window is cleared, and the author can
  edit with the reason in a banner

### Requirement: Bulk decisions are separate decisions

The bulk bar MUST say how many Reports it affects, MUST apply one shared reason, and MUST record a separate
decision per Report with its own timestamp. It MUST NOT act on a Report already decided.

#### Scenario: Bulk reject

- **WHEN** three pending Reports are rejected with one reason
- **THEN** each carries the reason and its own entry, and the selection clears

### Requirement: States

The queue MUST have loading, error with Retry, and empty states per tab and per filter.

#### Scenario: A failed load

- **WHEN** the queue fails to load
- **THEN** a message offers Retry and no blank table is shown

## API contract (documented, simulated today)

| Call | Method and path | Body | Success `data` | Errors |
|---|---|---|---|---|
| Queue | `GET /api/v1/reports?scope=review&periodId=&status=` | none | `{ reports: Report[], missing: MissingPerson[] }` | 401, 403 |
| Decide | `POST /api/v1/reports/:id/decision` | `{ decision, reason? }` | `Report` | 401, 403, 404, 409 |
| Bulk decide | `POST /api/v1/reports/decisions` | `{ ids, decision, reason }` | `Report[]` | 401, 403, 409 |

Guards: `jwt.validateToken`, role guard (Staff has no queue), then Space scope for a Head and Workspace
scope for an Admin. The server refuses a Head deciding their own Report.

## Frontend

- `/dashboard/review`: period header, tabs, chips with counts, table, bulk bar, decision dialogs, four states.
- Reached from the nav's Review item and the Review tab on a phone.
- Types: `ReviewTab`, `DecisionKind`, `DecisionInput`, `MissingPerson` in `src/lib/review.ts`.
